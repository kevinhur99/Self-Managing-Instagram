## Contributing to instapy-cli :tada: :tropical_drink:


Really want to contribute?
Start from here! Do a Pull Request with an updated CONTRIBUTING.md to support instapy-cli.

> instruction soon

Take inspiration from https://github.com/atom/atom/blob/master/CONTRIBUTING.md#git-commit-messages

*FOR ISSUE*
It's possile to record the terminal with ttystudio and upload a gif attached to the issue to see the problem :D


### New Release

A development wip of instapy-cli should be named '-devX', where X is the dev release version.

Instead all the releases that are considered stable should have no suffix.

Thanks! :cherries:

**b3nab** a.k.a. Benedetto Abbenanti