# Check if instapy return help view
instapy