#!/bin/zsh

python setup.py develop