#!/bin/zsh
# Release new version of instapy-cli
# from build process

twine upload dist/*