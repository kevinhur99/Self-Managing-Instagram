# iFunnyAPI
###### Interact with iFunny's API using python!

## Installation
```
python -m pip install ifunnyapi
```